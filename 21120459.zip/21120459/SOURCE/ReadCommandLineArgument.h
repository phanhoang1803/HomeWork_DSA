#pragma once
#include "InputDataProcessing.h"

CommandType readCommandTypeInput(int  argc, string* argv);